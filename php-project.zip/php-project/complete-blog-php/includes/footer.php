<!-- footer -->
<div class="footer">
			<p>Ambira Pradhan &copy; <?php echo date('Y'); ?></p>
		</div>
		<!-- // footer -->

	</div>
	<!-- // container -->
</body>
</html>